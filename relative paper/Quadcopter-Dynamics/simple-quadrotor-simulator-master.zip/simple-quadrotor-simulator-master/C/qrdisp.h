/*--------------------------------------------------------------------------
 * qrdisp -- simple vehicle 3D visualization
 *--------------------------------------------------------------------------
 */
extern viewpoint_t sim_viewpoint;
extern double tripod[3];
extern void redraw();
extern void init_disp(int argc, char **argv);
extern void start_disp();

